-------------------------------------
URL del sitio:
http://186.64.116.65/~feg12cmarchant/

-------------------------------------
Usuario y contraseña del sitio WP:

user: coni
Pass: Conibowie1503!

-------------------------------------

Nombre del proyecto: Nitrofilms

1. ¿Es un proyecto personal o para un tercero?
   Para un tercero.
2. Descripción breve del proyecto:
   Es un portafolio de trabajos para un estudio de Motion Graphics y VFX.
3. Estrategia: La estrategia aplicada busca diseñar un sitio sencillo y directo, donde sea posible encontrar los principales trabajos de Nitrofilms y así 	 tener una referencia de los servicios que ellos pueden desarrollar.
4. ¿Quiénes son los usuarios? Los usuarios serán posibles clientes que se encuentren en búsqueda de proveedores de servicios de diseño audiovisual.
5. ¿Cuál debería ser la conversión de éstos? La conversión de los usuarios debería resultar en contactar a los fundadadores de Nitrofilms para levantar una solicitud de presupuesto.

-------------------------------------
Wireframes de alta fidelidad

<img src="images/wireframes.png" alt="wireframes">

-------------------------------------
Screenshot GTmetrix antes:

<img src="images/GT-Metrix-Antes.png" alt="GT-Metrix">

Screenshot GTmetrix antes:

<img src="images/GT-Metrix-Despues.png" alt="GT-Metrix">

-------------------------------------
Ejemplo SEO en post de trabajos (no aplica al 100% ya que estos post no son de contenido escrito)

 <img src="images/Ejemplo-post-SEO-antes.png" alt="SEO">
 <img src="images/Ejemplo-post-SEO-despues.png" alt="SEO">
-------------------------------------
Sitemap
 <img src="images/Sitemap.png" alt="sitemap">
